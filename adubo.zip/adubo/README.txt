Cotidiano Sensitivo
http://cotidianosensitivo.info

adubo v.04 - software de envio de dados para a plataforma cotidianosensitivo.info - GPLv3
##############################################
Requisitos do Sistema:
Computador com Linux Ubuntu ou Debian.
Internet
WebCam
Pd-extended (http://puredata.info)
###########################################

Para instalar o software, siga os passos:
-----------------------------------------
1. Abra o terminal e execute o script cotidianosensitivo.sh para instalar as dependências. (sh cotidianosensitivo.sh)

2. Confirme se está conectado na Internet e com a camera instalada.

3. Abra o software adubo.pd pelo Pd-extended e siga as instruções indicadas no patch.

Caminhos do software:
---------------------------------------
1. Escolha o diretório onde será salva as imagens (de preferência dentro da pasta onde descompactou o cotidianosensitivo.zip)
2. Defina o dispositivo da camera (se está em /dev/video0, /dev/video1...)
3. Habilite a iris, neste passo a máquina Gem irá abrir com as informações da camera.
4. Habilite o DSP (Audio)
5. Defina o threshold do áudio.
6. Habilite o catalogo das imagens
7. Habilite a nuvem para enviar os dados para os servidores Cloud Computing.
8. Escolha um dos radares disponíveis
9. Receba os dados para verificar se está ok.
10. Verifique se as imagens estão chegando no site http://cotidianosensitivo.info (plataforma).

Em caso de dúvidas, verifique se as imagens estão sendo salvas na pasta determinada e verifique a Internet.

Contatos
rbrazileiro@gmail.com
rbrz@3ecologias.net
